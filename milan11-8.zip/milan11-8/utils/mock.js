let discover = [
  {
    img: '',
    title: '星巴克聊天群',
    message: '21',
    distance: '100'
  }
]

let talk = [
  {
    avatar: '',
    name: '张晓峰',
    isMe: false,
    mType: 'video',
    message: '',
    src: ''
  },
  {
    avatar: '',
    name: '',
    isMe: false,
    mType: 'message',
    message: '2017年6月28日 21:10',
    src: ''
  },
  {
    avatar: '',
    name: 'me',
    isMe: true,
    mType: 'text',
    message: '这个视频给力',
    src: ''
  },
  {
    avatar: '',
    name: '',
    isMe: false,
    mType: 'message',
    message: '2017年6月28日 21:10',
    src: ''
  },
  {
    avatar: '',
    name: '李诞',
    isMe: false,
    mType: 'img',
    message: '',
    src: '/image/img1.png'
  },
  {
    avatar: '',
    name: '张晓峰',
    isMe: false,
    mType: 'text',
    message: '666',
    src: ''
  },  
  {
    avatar: '',
    name: '狗剩',
    isMe: false,
    mType: 'img',
    message: '',
    src: '/image/img1.png'
  },
  {
    avatar: '',
    name: '',
    isMe: false,
    mType: 'message',
    message: '"Gcaufu小助手" 邀请 “志强” 加入群聊',
    src: ''
  },
  {
    avatar: '',
    name: '',
    isMe: false,
    mType: 'message',
    message: '禁止发布不良信息，被举报超过三次将会被系统自动踢出该聊天室',
    src: ''
  },
]

module.exports = {
  discover,
  talk
}