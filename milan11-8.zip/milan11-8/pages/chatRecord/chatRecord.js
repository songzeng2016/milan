// pages/chatRecord/chatRecord.js
const app = getApp()
const { wc } = app
let { openId } = app
const { host, data, isSuccess, success } = wc

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    openId = wx.getStorageSync('openId')
    let id = options.id
    const that = this

    // https://sp.yangchengtech.com/milian/Handler/Handler.ashx?Action=GetChatList&D=174&pageSize=20&pageIndex=1
    let getData = {
      Action: 'GetChatList',
      ID: id,
      pageSize: 20,
      pageIndex: 1
    }

    wc.get(getData, (json) => {
      if (json[isSuccess] === success) {
        for (let i in json[data]) {
          that.getMessage(json[data][i])
        }
      }
    })
  },

  // 处理接收的消息
  getMessage: function (json) {
    const that = this
    let talk = that.data.talk || []

    if (json.openid === openId) {
      json.isMe = true
    }

    talk.push(json)

    that.setData({
      talk,
      bottom: 'bottom'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})